package com.metallum.visual;

import com.metallum.Metallum;
import com.metallum.material.MaterialCatalog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import org.lwjgl.system.MemoryUtil;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** Bounded render-thread cache. Only unambiguous opaque cube model faces are supported. */
public final class NearbyMaterials implements AutoCloseable {
    private static final Direction[] FACES = {Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
    private static final Identifier CATALOG = Identifier.fromNamespaceAndPath("metallum", "materials/default.json");
    private final ByteBuffer data = MemoryUtil.memCalloc(MaterialGrid.BYTES);
    private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
    private final RandomSource random = RandomSource.create(0);
    private final List<BlockStateModelPart> parts = new ArrayList<>();
    private MaterialCatalog catalog = MaterialCatalog.empty();
    private Object world;
    private int revision = -1, cursor;
    public int x, y, z;
    public boolean ready;
    public long generation;

    public ByteBuffer data() { return data; }

    public void update(Minecraft client, double cameraX, double cameraY, double cameraZ) {
        int cx = (int) Math.floor(cameraX), cy = (int) Math.floor(cameraY), cz = (int) Math.floor(cameraZ);
        if (world != client.level || revision != VisualState.revision
                || Math.abs(cx - (x + 12)) > 4 || Math.abs(cy - (y + 12)) > 4 || Math.abs(cz - (z + 12)) > 4) {
            boolean reload = revision != VisualState.revision || world != client.level;
            world = client.level;
            revision = VisualState.revision;
            x = cx - 12; y = cy - 12; z = cz - 12;
            cursor = 0;
            ready = false;
            MemoryUtil.memSet(data, 0);
            if (reload) {
                try (var reader = client.getResourceManager().getResource(CATALOG).orElseThrow().openAsReader()) {
                    catalog = MaterialCatalog.read(reader);
                } catch (Exception exception) {
                    catalog = MaterialCatalog.empty();
                    Metallum.LOGGER.error("Visual material catalog unavailable; keeping surfaces unchanged", exception);
                }
            }
        }
        // shortcut: rolling snapshots can lag block edits by one sweep; add block-change invalidation if visible in target tests.
        for (int limit = Math.min(cursor + 768, MaterialGrid.CELLS); cursor < limit; cursor++) {
            int lx = cursor % MaterialGrid.SIDE;
            int lz = cursor / MaterialGrid.SIDE % MaterialGrid.SIDE;
            int ly = cursor / (MaterialGrid.SIDE * MaterialGrid.SIDE);
            pos.set(x + lx, y + ly, z + lz);
            int offset = cursor * 96;
            for (int i = 0; i < 24; i++) data.putFloat(offset + i * 4, 0);
            if (!client.level.hasChunk(pos.getX() >> 4, pos.getZ() >> 4)) { data.putFloat(offset + 12, -1); continue; }
            var state = client.level.getBlockState(pos);
            if (state.isAir()) continue;
            if (!state.isSolidRender() || !state.isCollisionShapeFullBlock(client.level, pos)) {
                data.putFloat(offset + 12, -1);
                continue;
            }
            parts.clear();
            random.setSeed(state.getSeed(pos));
            client.getModelManager().getBlockStateModelSet().get(state).collectParts(random, parts);
            for (int face = 0; face < 6; face++) {
                MaterialCatalog.Material material = null;
                boolean ambiguous = false;
                int count = 0;
                for (var part : parts) {
                    for (int list = 0; list < 2; list++) {
                        for (var quad : part.getQuads(list == 0 ? FACES[face] : null)) {
                            if (quad.direction() != FACES[face]) continue;
                            count++;
                            if (!fullFace(quad, face)) { ambiguous = true; continue; }
                            var candidate = catalog.get(quad.materialInfo().sprite().contents().name().toString());
                            if (candidate == MaterialCatalog.UNASSIGNED || candidate.transmission() > 0
                                    || (material != null && !material.equals(candidate))) ambiguous = true;
                            material = candidate;
                        }
                    }
                }
                if (ambiguous || count != 1 || material == null) continue;
                int at = offset + face * 16;
                data.putFloat(at, material.roughness());
                data.putFloat(at + 4, material.metalness());
                data.putFloat(at + 8, material.emission());
                data.putFloat(at + 12, 1);
            }
        }
        if (cursor == MaterialGrid.CELLS) {
            cursor = 0;
            ready = true;
            generation++;
        }
    }

    private static boolean fullFace(BakedQuad quad, int face) {
        int corners = 0;
        for (int i = 0; i < 4; i++) {
            var p = quad.position(i);
            if (!MaterialGrid.corner(p.x(), p.y(), p.z(), face)) return false;
            int bit = face < 2 ? (int) (p.x() + p.z() * 2)
                    : face < 4 ? (int) (p.x() + p.y() * 2) : (int) (p.z() + p.y() * 2);
            corners |= 1 << bit;
        }
        return corners == 15;
    }

    @Override public void close() { MemoryUtil.memFree(data); }
}
