#include <metal_stdlib>
using namespace metal;

struct VisualUniforms {
    float4x4 inverseViewProjection;
    float4x4 viewProjection;
    float4 cameraInGrid;
    float4 settings; // material diagnostic, unused, unused, unused
};
struct VisualVertex { float4 position [[position]]; };
vertex VisualVertex visual_vs(uint id [[vertex_id]]) {
    const float2 p[3] = {float2(-1, 1), float2(3, 1), float2(-1, -3)};
    return {float4(p[id], 0, 1)};
}
float3 positionAt(uint2 pixel, depth2d<float, access::read> depth, constant VisualUniforms& u) {
    float2 uv = (float2(pixel) + 0.5) / float2(depth.get_width(), depth.get_height());
    float4 p = u.inverseViewProjection * float4(uv * 2 - 1, depth.read(pixel), 1);
    return p.xyz / p.w;
}
float3 normalAt(uint2 pixel, depth2d<float, access::read> depth, constant VisualUniforms& u) {
    uint2 size(depth.get_width(), depth.get_height());
    uint2 l(pixel.x > 0 ? pixel.x - 1 : 0, pixel.y), r(min(pixel.x + 1, size.x - 1), pixel.y);
    uint2 b(pixel.x, pixel.y > 0 ? pixel.y - 1 : 0), t(pixel.x, min(pixel.y + 1, size.y - 1));
    float d = depth.read(pixel);
    float3 p = positionAt(pixel, depth, u);
    float3 dx = abs(depth.read(l) - d) < abs(depth.read(r) - d)
        ? p - positionAt(l, depth, u) : positionAt(r, depth, u) - p;
    float3 dy = abs(depth.read(b) - d) < abs(depth.read(t) - d)
        ? p - positionAt(b, depth, u) : positionAt(t, depth, u) - p;
    float3 n = cross(dx, dy);
    if (!all(isfinite(n)) || dot(n, n) < 1e-16) return float3(0);
    n = normalize(n);
    return dot(n, -p) < 0 ? -n : n;
}
int faceOf(float3 n) {
    if (abs(n.y) > 0.995) return n.y > 0 ? 1 : 0;
    if (abs(n.z) > 0.995) return n.z > 0 ? 3 : 2;
    if (abs(n.x) > 0.995) return n.x > 0 ? 5 : 4;
    return -1;
}
bool blockedPath(float3 p, constant VisualUniforms& u, device const float4* grid) {
    float3 delta = p;
    float3 start = u.cameraInGrid.xyz;
    int3 cell = int3(floor(start));
    int3 end = int3(floor(start + p - normalize(p) * 0.05));
    int3 step = int3(sign(delta));
    float3 stride = 1.0 / max(abs(delta), float3(1e-8));
    float3 boundary = float3(cell) + select(float3(0), float3(1), delta > 0);
    float3 next = abs(boundary - start) * stride;
    for (int i = 0; i < 72; i++) {
        if (any(cell < 0) || any(cell >= 24)) return true;
        if (grid[((cell.y * 24 + cell.z) * 24 + cell.x) * 6].w < 0) return true;
        if (all(cell == end)) return false;
        int axis = next.x < next.y ? (next.x < next.z ? 0 : 2) : (next.y < next.z ? 1 : 2);
        cell[axis] += step[axis];
        next[axis] += stride[axis];
    }
    return true;
}
float4 materialAt(float3 p, float3 n, constant VisualUniforms& u, device const float4* grid) {
    int face = faceOf(n);
    if (face < 0 || !all(isfinite(p))) return float4(0);
    float3 g = p + u.cameraInGrid.xyz;
    int axis = face < 2 ? 1 : (face < 4 ? 2 : 0);
    if (abs(g[axis] - round(g[axis])) > 0.035) return float4(0);
    int3 cell = int3(floor(g - n * 0.04));
    if (any(cell < 0) || any(cell >= 24)) return float4(0);
    float4 m = grid[((cell.y * 24 + cell.z) * 24 + cell.x) * 6 + face];
    // A blended world color may contain glass/water while depth still identifies its opaque background.
    if (m.w > 0 && blockedPath(p, u, grid)) return float4(0);
    return m;
}
float3 linearColor(float3 c) { return pow(max(c, 0.0), float3(2.2)); }
float3 reflection(float3 p, float3 n, float roughness, texture2d<float, access::read> color,
        depth2d<float, access::read> depth, constant VisualUniforms& u, thread float& confidence) {
    float3 ray = reflect(normalize(p), n);
    float3 start = p + n * 0.07;
    float previous = -1, previousDistance = 0;
    uint2 size(color.get_width(), color.get_height());
    for (int step = 1; step <= 24; step++) {
        float distance = 0.12 * step + 0.018 * step * step;
        float3 q = start + ray * distance;
        float4 clip = u.viewProjection * float4(q, 1);
        if (clip.w <= 0) break;
        float2 uv = clip.xy / clip.w * 0.5 + 0.5;
        if (any(uv < 0.005) || any(uv > 0.995)) break;
        uint2 pixel = min(uint2(uv * float2(size)), size - 1);
        float d = depth.read(pixel);
        if (d <= 1e-7) { previous = -1; previousDistance = distance; continue; }
        float3 surface = positionAt(pixel, depth, u);
        float delta = length(q) - length(surface);
        if (previous < 0 && delta >= 0) {
            float low = previousDistance, high = distance;
            // Refine the crossing so the fixed march does not jump through thin geometry.
            for (int refine = 0; refine < 5; refine++) {
                float middle = (low + high) * 0.5;
                float3 point = start + ray * middle;
                float4 projected = u.viewProjection * float4(point, 1);
                float2 middleUV = projected.xy / projected.w * 0.5 + 0.5;
                uint2 sample = min(uint2(clamp(middleUV, 0.0, 1.0) * float2(size)), size - 1);
                float difference = depth.read(sample) <= 1e-7 ? -1 : length(point) - length(positionAt(sample, depth, u));
                if (difference >= 0) high = middle; else low = middle;
            }
            q = start + ray * high;
            clip = u.viewProjection * float4(q, 1);
            uv = clip.xy / clip.w * 0.5 + 0.5;
            pixel = min(uint2(clamp(uv, 0.0, 1.0) * float2(size)), size - 1);
            surface = positionAt(pixel, depth, u);
            delta = length(q) - length(surface);
            if (depth.read(pixel) <= 1e-7 || delta < 0 || delta > 0.18 + high * 0.025
                    || length(surface - p) <= 0.25) {
                previous = delta;
                previousDistance = distance;
                continue;
            }
            float edge = min(min(uv.x, 1 - uv.x), min(uv.y, 1 - uv.y));
            confidence = smoothstep(0.005, 0.12, edge) * (1 - distance / 14.0);
            int radius = int(roughness * 5);
            int2 a = clamp(int2(pixel) + int2(radius, 0), int2(0), int2(size) - 1);
            int2 b = clamp(int2(pixel) - int2(radius, 0), int2(0), int2(size) - 1);
            return linearColor((color.read(pixel).rgb * 2 + color.read(uint2(a)).rgb + color.read(uint2(b)).rgb) * 0.25);
        }
        previous = delta;
        previousDistance = distance;
    }
    confidence = 0;
    return float3(0);
}
fragment float4 visual_fs(VisualVertex in [[stage_in]],
        texture2d<float, access::read> color [[texture(0)]], depth2d<float, access::read> depth [[texture(1)]],
        constant VisualUniforms& u [[buffer(0)]], device const float4* grid [[buffer(1)]]) {
    uint2 pixel = uint2(in.position.xy);
    float4 original = color.read(pixel);
    if (depth.read(pixel) <= 1e-7) return original;
    float3 p = positionAt(pixel, depth, u), n = normalAt(pixel, depth, u);
    float4 m = materialAt(p, n, u, grid);
    if (u.settings.x > 0.5) {
        if (m.w < 0.5) return float4(original.rgb * 0.25, original.a);
        return float4(m.z > 0 ? float3(1, 0.25, 0.05)
            : m.y > 0.5 ? float3(1, 0.8, 0.1) : float3(0.1, 1 - m.x * 0.6, m.x), original.a);
    }
    if (m.w < 0.5) return original;
    float3 base = linearColor(original.rgb);
    float3 view = normalize(-p), light = normalize(float3(-0.4, 0.8, 0.3));
    float facing = max(dot(n, light), 0.0);
    float roughness = clamp(m.x, 0.08, 1.0);
    float3 f0 = mix(float3(0.04), base, m.y);
    float3 fresnel = f0 + (1 - f0) * pow(1 - max(dot(n, view), 0.0), 5.0);
    // shortcut: artistic unshadowed highlight over the already-lit scene; replace when a lighting G-buffer exists.
    float specular = pow(max(dot(n, normalize(light + view)), 0.0), mix(160.0, 4.0, roughness * roughness));
    float3 result = base * (0.82 + 0.18 * facing) + f0 * specular * (1 - roughness) * 0.55;
    if (roughness < 0.65) {
        float confidence;
        float3 reflected = reflection(p, n, roughness, color, depth, u, confidence);
        float3 weight = fresnel * (1 - roughness) * confidence * 0.7;
        result = result * (1 - weight) + reflected * weight;
    }
    result += base * m.z * 0.65;
    uint2 size(color.get_width(), color.get_height());
    const int2 taps[8] = {int2(8,0), int2(-8,0), int2(0,8), int2(0,-8),
        int2(18,18), int2(-18,18), int2(18,-18), int2(-18,-18)};
    // shortcut: visible screen neighbors only, without light visibility/shadows; this is not global illumination.
    for (int i = 0; i < 8; i++) {
        uint2 q = uint2(clamp(int2(pixel) + taps[i], int2(0), int2(size) - 1));
        if (depth.read(q) <= 1e-7) continue;
        float3 ep = positionAt(q, depth, u);
        float4 em = materialAt(ep, normalAt(q, depth, u), u, grid);
        if (em.w < 0.5 || em.z <= 0) continue;
        float3 source = linearColor(color.read(q).rgb);
        float3 delta = ep - p;
        float distance = length(delta);
        float local = distance > 0.1 && distance < 4 ? max(dot(n, delta / distance), 0.0) / (1 + distance * distance) : 0;
        result += source * em.z * (0.012 + local * 0.12);
    }
    // Bounded highlight compression; preserve the original alpha and the fallback image exactly.
    result = result / max(float3(1), result * 0.5 + 0.5);
    float3 g = p + u.cameraInGrid.xyz;
    float edge = min(min(min(g.x, g.y), g.z), min(min(24 - g.x, 24 - g.y), 24 - g.z));
    float3 shaded = pow(max(result, 0.0), float3(1.0 / 2.2));
    return float4(mix(original.rgb, shaded, smoothstep(0.5, 2.0, edge)), original.a);
}
